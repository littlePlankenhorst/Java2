package plant;

public interface Plant {
    public double getOxigenAmountPerYear();
    public int getLifeTime();
    public String getRepresentation();
}
