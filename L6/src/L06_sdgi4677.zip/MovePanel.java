import java.awt.*;
import javax.swing.*;

public class MovePanel extends JPanel {
    private int posX = 40; // Initial X position of the circle
    private int posY = 20; // Initial Y position of the circle

    public MovePanel() {
        // Set the preferred size of the panel
        setPreferredSize(new Dimension(500, 400));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // Call super to clear the previous drawings
        g.setColor(Color.BLUE); // Set the color to blue
        g.fillOval(posX, posY, 50, 50); // Draw the circle at the updated position
    }

    public void moveCircle(int deltaX, int deltaY) {
        // Calculate new positions
        int newX = posX + deltaX;
        int newY = posY + deltaY;

        // Check boundaries to prevent moving outside the panel
        if (newX >= 0 && newX <= getWidth() - 50) { // 50 is the circle's width
            posX = newX;
        }
        if (newY >= 0 && newY <= getHeight() - 50) { // 50 is the circle's height
            posY = newY;
        }

        repaint(); // Repaint the panel to update the circle's position
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("MoveCircleFrame");
        frame.setSize(500, 500);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false); // Make the frame non-resizable

        MovePanel panel = new MovePanel();
        frame.add(panel, BorderLayout.CENTER);

        // Create buttons for movement
        JButton upButton = new JButton("↑");
        JButton downButton = new JButton("↓");
        JButton leftButton = new JButton("←");
        JButton rightButton = new JButton("→");

        // Add action listeners to buttons
        upButton.addActionListener(e -> panel.moveCircle(0, -10));
        downButton.addActionListener(e -> panel.moveCircle(0, 10));
        leftButton.addActionListener(e -> panel.moveCircle(-10, 0));
        rightButton.addActionListener(e -> panel.moveCircle(10, 0));

        // Add buttons to the frame
        frame.add(upButton, BorderLayout.NORTH);
        frame.add(downButton, BorderLayout.SOUTH);
        frame.add(leftButton, BorderLayout.WEST);
        frame.add(rightButton, BorderLayout.EAST);

        frame.setVisible(true);
    }
}