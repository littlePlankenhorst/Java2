import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;
import javax.swing.*;

public class PushFrame extends JFrame {
    private JButton button;
    private Random random;

    public PushFrame() {
        // Initialize the Random object
        random = new Random();

        // Set up the frame
        setTitle("Push Frame");
        setSize(400, 400);
        setMinimumSize(new Dimension(300, 300)); // Set minimum size for the frame
        setLayout(null); // No layout manager

        // Create the button
        button = new JButton("Push me!");
        button.setBounds(150, 150, 100, 50); // Initial position and size of the button

        // Add mouse listener to the button
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                moveButton(e);
            }
        });

        // Add the button to the frame
        add(button);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void moveButton(MouseEvent e) {
        // Generate random coordinates for the button
        int newX, newY;
        do {
            newX = random.nextInt(getWidth() - button.getWidth());
            newY = random.nextInt(getHeight() - button.getHeight());
        } while (isUnderMouse(newX, newY, e));

        // Move the button to the new position
        button.setBounds(newX, newY, button.getWidth(), button.getHeight());
    }

    private boolean isUnderMouse(int x, int y, MouseEvent e) {
        // Check if the new position is under the mouse cursor
        return (x < e.getX() && x + button.getWidth() > e.getX() &&
                y < e.getY() && y + button.getHeight() > e.getY());
    }

    public static void main(String[] args) {
        new PushFrame(); // Create an instance of PushFrame
    }
}
